package com.example.scoretracker

import android.media.MediaPlayer
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var score = 0
    private lateinit var scoreText: TextView

    private lateinit var clickSound: MediaPlayer
    private lateinit var winSound: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scoreText = findViewById(R.id.scoreText)

        val addBtn = findViewById<Button>(R.id.addBtn)
        val minusBtn = findViewById<Button>(R.id.minusBtn)
        val resetBtn = findViewById<Button>(R.id.resetBtn)

       // clickSound = MediaPlayer.create(this, R.raw.click_sound)
        //winSound = MediaPlayer.create(this, R.raw.win_sound)

        if (savedInstanceState != null) {
            score = savedInstanceState.getInt("score")
        }

        updateScore()

        addBtn.setOnClickListener {
            score++
            Log.d("ScoreApp", "Add button pressed")
            clickSound.start()
            checkWin()
            updateScore()
        }

        minusBtn.setOnClickListener {
            score--
            Log.d("ScoreApp", "Minus button pressed")
            clickSound.start()
            updateScore()
        }

        resetBtn.setOnClickListener {
            score = 0
            Log.d("ScoreApp", "Reset button pressed")
            updateScore()
        }
    }

    private fun updateScore() {
        scoreText.text = score.toString()
    }

    private fun checkWin() {
        if (score == 15) {
            winSound.start()
            Log.d("ScoreApp", "Team reached 15 points")
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("score", score)
    }
}